﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _108b期_Csharp_期末考試
{
    class FinalTest_Ex6
    {

        static int mod(int x, int y) {


            return x%y;        
        }


        public static void Ex6()
        {

            Console.WriteLine("mod(17,5)="+mod(17,5));


            Console.Read();
        } 
    }
}
